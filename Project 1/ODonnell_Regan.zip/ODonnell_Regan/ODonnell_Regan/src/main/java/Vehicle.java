public class Vehicle {
	private String make;
	private int size;
	private double weight;
	private double engineSize;
}
