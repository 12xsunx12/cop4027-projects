import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class ExampleSquareRace extends Application {

    private Thread animationThread;
    private Canvas canvas;
    private double squareX = 0;
    private boolean animationRunning = false;

    @Override
    public void start(Stage primaryStage) {
        canvas = new Canvas(400, 400);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        drawSquare(gc);

        Button startButton = new Button("Start");
        startButton.setOnAction(e -> startAnimation());

        Button resetButton = new Button("Reset");
        resetButton.setOnAction(e -> resetAnimation());

        HBox buttonBox = new HBox(10, startButton, resetButton);
        VBox root = new VBox(10, canvas, buttonBox);
        root.setStyle("-fx-padding: 10px");

        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Square Animation");
        primaryStage.show();
    }

    private void drawSquare(GraphicsContext gc) {
        gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        gc.setFill(Color.BLUE);
        gc.fillRect(squareX, 180, 50, 50);
    }

    private void startAnimation() {
        if (animationThread != null && animationThread.isAlive()) {
            return;
        }

        animationRunning = true;
        animationThread = new Thread(() -> {
            while (animationRunning) {
                squareX += 5;
                if (squareX > canvas.getWidth()) {
                    squareX = 0;
                }

                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }

                drawSquare(canvas.getGraphicsContext2D());
            }
        });
        animationThread.start();
    }

    private void resetAnimation() {
        animationRunning = false;
        if (animationThread != null && animationThread.isAlive()) {
            animationThread.interrupt();
        }
        squareX = 0;
        drawSquare(canvas.getGraphicsContext2D());
    }

    public static void main(String[] args) {
        launch(args);
    }
}