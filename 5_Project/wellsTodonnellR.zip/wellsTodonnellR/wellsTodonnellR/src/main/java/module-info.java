module project5.project5 {
    requires javafx.controls;
	requires java.sql;
	requires javafx.base;
	requires java.desktop;
	requires javafx.graphics;
    exports project5;
}
